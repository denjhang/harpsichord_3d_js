// Part of the Chili3d Project, under the AGPL-3.0 License.
// See LICENSE file in the project root for full license information.

import {
    command,
    GetOrSelectNodeStep,
    type INode,
    type IStep,
    MultistepCommand,
    PubSub,
    Transaction,
} from "@chili3d/core";

@command({
    key: "modify.deleteNode",
    icon: "icon-delete",
})
export class Delete extends MultistepCommand {
    protected override executeMainTask(): void {
        const nodes: INode[] | undefined = this.stepDatas[0].nodes;
        if (!nodes || nodes.length === 0) {
            PubSub.default.pub("showToast", "toast.select.noSelected");
            return;
        }

        if (
            this.document.modelManager.currentNode &&
            nodes.includes(this.document.modelManager.currentNode)
        ) {
            this.document.modelManager.currentNode = this.document.modelManager.rootNode;
        }

        this.document.selection.clearSelection();
        Transaction.execute(this.document, "delete", () => {
            nodes.forEach((model) => model.parent?.remove(model));
        });
        this.document.visual.update();
        PubSub.default.pub("showToast", "toast.delete{0}Objects", nodes.length);
    }

    protected override getSteps(): IStep[] {
        return [new GetOrSelectNodeStep("prompt.select.models", { multiple: true })];
    }
}
