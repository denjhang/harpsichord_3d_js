// Part of the Chili3d Project, under the AGPL-3.0 License.
// See LICENSE file in the project root for full license information.

import {
    command,
    EditableShapeNode,
    I18n,
    type IStep,
    MultistepCommand,
    PubSub,
    property,
    SelectShapeStep,
    ShapeTypes,
    Transaction,
} from "@chili3d/core";

@command({
    key: "create.thickSolid",
    icon: "icon-thickSolid",
})
export class ThickSolidCommand extends MultistepCommand {
    @property("option.command.thickness")
    get thickness() {
        return this.getPrivateValue("thickness", 10);
    }
    set thickness(value: number) {
        this.setProperty("thickness", value);
    }

    protected override executeMainTask(): void {
        Transaction.execute(this.document, `excute ${Object.getPrototypeOf(this).data.name}`, () => {
            this.stepDatas[0].shapes.forEach((x) => {
                const subShape = shapeFactory.makeThickSolidBySimple(x.shape, this.thickness);
                if (!subShape.isOk) {
                    PubSub.default.pub("showToast", "toast.converter.error");
                    return;
                }
                const model = new EditableShapeNode({
                    document: this.document,
                    name: I18n.translate("command.create.thickSolid"),
                    shape: subShape,
                });

                const node = x.owner.node;
                model.transform = node.transform;
                node.parent!.insertAfter(node, model);
            });
            this.document.visual.update();
            PubSub.default.pub("showToast", "toast.success");
        });
    }

    protected override getSteps(): IStep[] {
        return [new SelectShapeStep(ShapeTypes.face, "prompt.select.faces", { multiple: true })];
    }
}
